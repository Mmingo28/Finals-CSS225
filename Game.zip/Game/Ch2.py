#Chapter2
import random
import Ch3

inventory2 = []

def start2():
    print(inventory2)
    print("Find a enemy with a key in Greenwood forest")
    print("Forest enemy has been found")
    print("You both are ready for battle")
    enemydamage = 0
    playerdamage = 0
    fighting=True
    while fighting is True:
        Fight= input(str("Choose how you want to fight. Which number? 1.Attack 2.Defend 3.Special"))
        if Fight == "1":
            enemydamage = enemydamage+random.randrange(0,100)
            playerdamage = playerdamage+random.randrange(0,100)
            print("player attacks and damages enemy. Enemy life is low. The enemy got ", enemydamage," damage")
            print("enemy attacks player damage is very low. The player got ", playerdamage, " damage")
        elif Fight == "2":
            print("Player takes no damage at all")
        else:
            fighting = False
            print("player does one of the 3 random special moves")
            if playerdamage < 50:
                print("player beats the enemy and gets key")
                inventory2.append("Key")
            else:
                print("Secondary win. player wins but loses key")
            if "Key" in inventory2:
                Ch3.startKey()
            else:
                Ch3.startNoKey()

                
    #Attack and Defeat the enemy
    #Random 1-3
    #1:Defeat enemy and have key
    #2:Defeat enemy and lose key. Go back to Greenwood.
    #3:Defeated or you Die.




