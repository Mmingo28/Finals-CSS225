#Chapter1
import Ch2

inventory = []

def start1():
    print("Found potion")

    inventory.append("HP Potion")
    direction = True
    while direction == True:
        L = input("choose a path that may lead to Greenwood. Which path? Left or Right?")
        if L == "Left":
            '''Left path gets lost
            input("that is not the right path"))'''
            print("player gets lost and comes back to the path")

        else:   
        #R == "Right"

            print("You travel and arrive at Greenwood")
            print("You rest and sleep at Greenwood")
            print("End of chapter 1")
            break
#               Right path finds Greenwood, then it is correct
#               input("this is the correct path"))
start1()
Ch2.start2()


