def startKey():
    print("arrives at tower")

    print("use the key to open the door to tower")
    print("find and defeat final boss")
    

def startNoKey():
    print("player and allies open the tower")
    print("find and defeat final boss")
    



    #Find the Final Boss on top of the tower
    #Defeat the final boss.
    #1:Defeat Boss and save Greenwood.
    #2: Die or let boss escape and he enslaves or take or the world.


